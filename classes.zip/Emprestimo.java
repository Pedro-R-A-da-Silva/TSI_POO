public class Emprestimo{
  private long dataDeEmprestimo;
  private long dataPrevistaDeDevoluçao;
  private long dataDeEntregaReal;
  private int situação;

  public Emprestimo(long dataDeEmprestimo,long dataPrevistaDeDevoluçao, long dataDeEntregaReal, int situação){
    this.dataDeEmprestimo = dataDeEmprestimo;
    this.dataPrevistaDeDevoluçao = dataPrevistaDeDevoluçao;
    this.dataDeEntregaReal = dataDeEntregaReal;
    this.situação = situação;
  }

  public long getDataDeEmprestimo(){
    return dataDeEmprestimo;
  } 
  public void setDataDeEmprestimo(long dataDeEmprestimo){
    this.dataDeEmprestimo = dataDeEmprestimo;
  } 

  public long getDataPrevistaDeDevoluçao(){
    return dataPrevistaDeDevoluçao;
  } 
  public void setDataPrevistaDeDevoluçao(long dataPrevistaDeDevoluçao){
    this.dataPrevistaDeDevoluçao = dataPrevistaDeDevoluçao;
  } 


  public long getDataDeEntregaReal(){
    return dataDeEntregaReal;
  } 
  public void setDataDeEntregaReal(long dataDeEntregaReal){
    this.dataDeEntregaReal = dataDeEntregaReal;
  } 
  
  public int getSituação(){
    return situação;
  } 
  public void setSituação(int situação){
    this.situação = situação;
  } 

}