public class Usuario{
  private String nome;
  private long cpf;
  private String telefone;
  private String matricula;

  public Usuario(String nome, long cpf,String telefone, String matricula ){
    this.nome = nome;
    this.cpf = cpf;
    this.telefone = telefone;
    this.matricula = matricula;
  }

  public String getNome(){
    return nome;
  } 
  public void setNome(String nome){
    this.nome = nome;
  } 

  public long getCpf(){
    return cpf;
  } 
  public void setCpf(int cpf){
    this.cpf = cpf;
  } 
  
  public String getTelefone(){
    return telefone;
  } 
  public void setTelefone(String telefone){
    this.telefone = telefone;
  } 

  public String getMatricula(){
    return matricula;
  } 
  public void setMatricula(String matricula){
    this.matricula = matricula;
  } 


  

}