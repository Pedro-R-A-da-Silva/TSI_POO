import java.util.Date;

public class Livros{
  private String titulo;
  private String autor;
  private long ano;
  private int ediçao;
  private String editora;
  private String ISBN;

  public Livros(String titulo, String autor,long ano, int ediçao, String editora, String ISBN ){
    this.titulo = titulo;
    this.autor = autor;
    this.ano = ano;
    this.ediçao = ediçao;
    this.editora = editora;
    this.ISBN = ISBN;
  }

  public String getTitulo(){
    return titulo;
  } 
  public void setTitulo(String titulo){
    this.titulo = titulo;
  } 

  public String getAutor(){
    return autor;
  } 
  public void setAutor(String autor){
    this.autor = autor;
  } 


  public long getAno(){
    return ano;
  } 
  public void setAno(){
    this.ano = ano;
  } 
  
  public int getEdiçao(){
    return ediçao;
  } 
  public void setEdiçao(int ediçao){
    this.ediçao = ediçao;
  } 

  public String getEditora(){
    return editora;
  } 
  public void setEditora(String editora){
    this.editora = editora;
  } 
  public void setISBN(String ISBN){
    this.ISBN = ISBN;
  } 


  

}