class Main{
  public static void main(String[] args){
    Usuario Paulo = new Usuario("Paulo", 10785496818L,"987548658","184689" ){
      
          Emprestimo paulo_10785496818 = new Emprestimo(17/11/2021L, 07/12/2021L, 8/12/2021L, 1);

    };

    Livros MACHADO_D_ASSIS_CONTOS = new Livros("CONTOS-MACHADO DE ASSIS - 1ªED.(2021)", "MACHADO D ASSIS", 01/11/2021L, 1, "Itatiaia", "9788531907869" );

    Exemplar MACHADO_D_ASSIS_CONTOS_156 = new Exemplar(156L, false, true);
  }
}