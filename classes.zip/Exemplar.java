public class Exemplar{
  private long codigo;
  private boolean cativa;
  private boolean emprestada;

  public Exemplar(long codigo,boolean cativa, boolean emprestada){
    this.codigo = codigo;
    this.cativa = cativa;
    this.emprestada = emprestada;
  }

  public long getCodigo(){
    return codigo;
  } 
  public void setCodigo(long codigo){
    this.codigo = codigo;
  } 

  public boolean getCativa(){
    return cativa;
  } 
  public void setCativa(boolean cativa){
    this.cativa = cativa;
  } 


  public boolean getEmprestada(){
    return emprestada;
  } 
  public void setEmprestada(boolean emprestada){
    this.emprestada = emprestada;
  } 

}